# Node Numbering & Name
Node Number: 4-highlight.md
Node Name: The Crown and the Thorns of Eighteen
Preceding Node: 3-normal.md

## I. Event Positioning
**Event Type:** Highlight Mainline Event
**Dungeon:** Carteret Family Mansion
**Main Output:** Mother’s heirloom bracelet (major plot item & emotional anchor), Aiden’s necklace (relationship token), family’s public affirmation, preparation for the party night.

## II. Characters Present
**Name:** Super Aves
**Identity/Status:** Birthday girl, seeking normalcy and joy on her milestone day.
**Visual Feature List (Morning - > Evening):**
- **A. Outfit (Morning):**
  - Top: Sleeveless gray cotton tank top.
  - Bottom: Light gray cotton sleep shorts.
  - Footwear: None.
- **B. Outfit (Evening):**
  - Top/Bottom: Crimson satin slip dress with thin spaghetti straps, hugging her curves, off-shoulder, hem ending several inches above the knee.
  - Footwear: White sneakers (chosen over heels).
- **C. Accessories & Equipment (Evening):**
  - The silver bracelet with a central diamond (mother’s heirloom) on left wrist.
  - The silver necklace with diamond-studded initial “A” (from Aiden) around her neck.
  - Hair styled in loose, soft curls; smoky eye makeup accentuating green eyes.

**Name:** Summer
**Identity/Status:** Best friend, co-conspirator, party planner.
**Visual Feature List:**
- **A. Outfit:** An elegant party dress (style unspecified, matching the surprise theme).
- **B. Accessories & Equipment:** Likely carrying her gift bag (Victoria’s Secret) earlier.

**Name:** Zach
**Identity/Status:** Hungry, straightforward brother.
**Visual Feature List (Morning):**
- **A. Outfit:** Likely casual sleepwear or loungewear.
- **B. Accessories & Equipment:** None specified.

**Name:** Hunter
**Identity/Status:** The “chef” and joker brother.
**Visual Feature List:**
- **A. Outfit:** Casual home clothes.
- **B. Accessories & Equipment:** Holding the takeout pancake box.

**Name:** Xavier
**Identity/Status:** Family head/authority figure, bearer of the heirloom.
**Visual Feature List:**
- **A. Outfit:** Likely smart-casual attire (polo shirt, trousers) suitable for a home office.
- **B. Accessories & Equipment:** Carrying the small red velvet box.

**Name:** Tristan
**Identity/Status:** Observant, teasing brother, gift-giver.
**Visual Feature List:**
- **A. Outfit:** Relaxed, stylish loungewear.
- **B. Accessories & Equipment:** Holding the book gift.

**Name:** Aiden
**Identity/Status:** Protective, emotionally complex brother.
**Visual Feature List (Morning):**
- **A. Outfit:** White crewneck T-shirt, black distressed jeans with rips at the knees.
  - Bottom: Black distressed jeans.
  - Footwear: Likely boots or sneakers.
- **B. Accessories & Equipment:** Silver chain partially visible under the T-shirt collar. Carrying the black velvet jewelry box.

**Name:** Ashton
**Identity/Status:** Younger brother, slightly overwhelmed by Summer’s energy.
**Visual Feature List:** Casual teenage attire.

**Name:** Parker
**Identity/Status:** Teenage brother, eager to leave for his friend’s house.
**Visual Feature List:** Casual going-out clothes.

## III. Key Dialogue
△Summer: “Happy birthday! Wake up! Avery!”
△Zach: “Happy birthday sleepy head. I’m hungry and the guys won’t let me eat until you come downstairs so hurry the fuck up.”
△Xavier: (Placing the red box) “Dad said to give it to you. It was from mom.”
△Aves: “Oh,” (Forcing back tears)
△Summer (evening): “You look hot!”
△Aves (evening): “I’m fine. Red lips aren’t for me.”

## IV. Context
Following the tense “boyfriend inspection” dinner, Super Aves’s 18th birthday arrives as a promised oasis of normal celebration. The day is structured around family traditions—being woken up, a special breakfast, gift-giving—culminating in the much-anticipated house party that she and Summer have fought for. The emotional core revolves around receiving her late mother’s bracelet, a tangible link to her past, and Aiden’s uncharacteristically personal gift.

## V. Event Description
From dawn to dusk, Super Aves experiences her 18th birthday within the Carteret mansion. The day begins with a chaotic, affectionate wake-up call from Summer and Zach. A family breakfast follows, featuring Hunter’s “homemade” pancakes and Xavier’s customary caramel iced coffee. The gift-opening session is a mix of warmth and hilarious embarrassment: Tristan gives a desired book, Summer presents scandalous lingerie (to the brothers’ horror), Aiden gifts a personalized silver necklace, and finally, Xavier delivers the emotional climax—a silver bracelet from Super Aves’s deceased mother, passed on by their father. The afternoon is casual, filled with takeout food and sibling banter. As evening falls, Super Aves and Summer prepare for the party, with Super Aves choosing a stunning red dress but opting for comfort (sneakers, no red lipstick) over full glamour. She locks her bedroom door and, arm-in-arm with Summer, descends to face the already-booming celebration below.

## VI. Core Conflict
Balancing the desire for a perfect, normal teenage birthday with the overwhelming weight of family love, loss, and protection. The conflict is internal: embracing joy while managing the floodgate of emotions opened by her mother’s memory, and externally: stepping from the private, familial sphere into the public, social arena of the party as a newly-minted adult.

## VII. Scripted Intro Text (intro_plot_text)
**Time:** Dawn. Pale blue light seeps through the gaps in the curtains.
**Scene:** Super Aves’s bedroom. A fortress of blankets and pillows.
**Characters:** Super Aves (sleeping), Summer, Zach.

**△SFX:** The *thump* of the bedroom door flying open.

The camera is a close-up on Super Aves’s face, buried in a pillow. A sudden weight lands on the bed, jolting the frame.
**△Summer:** (Bright, piercing) “Happy birthday!”

A hand—Summer’s—tugs at the pillow. Super Aves’s fingers clutch it tighter, a muffled groan her only defense.
**△Aves:** (Muffled) “Thank you and no.”

A second pair of hands—larger, male—joins the fray from the other side. The pillow is ripped away. The camera pulls back to reveal Zach leaning over the bed, his face a mask of exaggerated starvation.
**△Zach:** “Happy birthday sleepy head. I’m hungry and the guys won’t let me eat until you come downstairs so hurry the fuck up.”

Super Aves’s eyes crack open one at a time. A sliver of green focuses on him.
**△Aves:** “pancakes?”
**△Zach:** “What else?”

A small, genuine smile touches her lips. She starts to push the duvet aside. Summer’s expression suddenly lights up with mischievous remembrance.
**△Summer:** “I forgot.”

Before Super Aves can react, Summer’s hands are above her, a shower of tiny, multi-colored paper shapes raining down. They catch the dawn light as they settle in her hair, on her lashes, across the white sheets.
**△Summer:** “Happy birthday!”

Close-up on Super Aves’s face, now speckled with confetti. Her eyes widen in mock-annoyance, but the morning light softens the edges. She’s awake. She’s eighteen. The day has officially begun, and she is caught, suspended between the warmth of their attention and the minor chaos they bring.

## VIII. Player Choice Moments
**Choice 1 (No Check Required):**
**Situation:** Confetti is in your hair and bed. Zach is waiting for you to go eat. Summer is beaming.
1.  **Option Description:** Grumble but get up, then hug Zach for the wake-up call.
    **Choice Result:** You play along with the morning chaos. The hug makes Zach smirk and ruffle your confetti-filled hair, establishing a light-hearted, affectionate tone for the day.
2.  **Option Description:** Pull the duvet back over your head, demanding five more minutes.
    **Choice Result:** Summer immediately jumps on you, starting a playful wrestling match. Zach sighs loudly about his hunger, but a smile tugs at his lips. The day starts with physical, sibling-like banter.

**Choice 2 (Label: Check Required):**
**Situation:** In front of all your brothers, Summer grins and urges you to keep pulling items from the large pink bag. Your hand just touched the first lace thong.
1.  **Option Description:** Laugh it off dramatically and hold up the lingerie as a “trophy.”
    **[Backend Check Logic]**: Check Attribute: Charisma. Difficulty: Challenging
    **Choice Result (Success):** Your boldness turns the tables. The brothers groan and look away, but Tristan chuckles approvingly and Hunter gives you a ‘well-played’ nod. You defuse the embarrassment with confidence.
    **Choice Result (Failure):** Your laugh sounds forced. The gesture falls flat, making the moment more awkward. Aiden frowns, and Xavier’s gaze turns stern, silently judging the maturity of the gift.
2.  **Option Description:** Shove everything back in the bag instantly with a mortified shriek.
    **[Backend Check Logic]**: Check Attribute: Willpower. Difficulty: Normal
    **Choice Result (Success):** Your genuine, flustered reaction is endearing. Hunter makes a joke to break the tension, and the brothers quickly move on, secretly relieved. It reinforces your ‘little sister’ image.
    **Choice Result (Failure):** Your panic is palpable. Summer doubles over laughing, and the brothers exchange amused, knowing looks. You feel intensely scrutinized and childish in comparison to Summer’s boldness.

**Choice 3 (Label: Check Required):**
**Situation:** At your bedroom door, Summer holds out a tube of classic red lipstick. The music from downstairs thumps through the floor. She says it would be perfect with the dress.
1.  **Option Description:** Shake your head firmly. Red lips aren’t you. You’re ready as you are.
    **[Backend Check Logic]**: Check Attribute: Willpower. Difficulty: Normal
    **Choice Result (Success):** You hold your ground. Summer shrugs, smiles, and links her arm with yours, respecting your choice. You descend feeling authentically yourself, comfortable in your skin and your sneakers.
    **Choice Result (Failure):** Under her expectant gaze and the party pressure, you doubt yourself. You let her apply the lipstick. It looks striking but feels like a costume. You spend the first part of the party feeling oddly disconnected from your reflection.
2.  **Option Description:** Hesitate, then take the lipstick and apply it yourself, a bold change for a bold night.
    **[Backend Check Logic]**: Check Attribute: Charisma. Difficulty: Hard
    **Choice Result (Success):** The transformation is stunning. Summer gasps in approval. When you enter the party, the new look grants you an immediate surge of confidence and commands attention, making you feel truly “eighteen.”
    **Choice Result (Failure):** The application is messy, or the color clashes with your complexion. You feel self-conscious instead of confident. It becomes a distracting flaw you’re hyper-aware of all night.

## IX. Subsequent Influence
**Perfect Outcome:** > The day’s warmth and your authentic choices solidified your place in the family heart. You gained 【The Carteret Brothers: Their protective love is tinged with newfound respect for your growing individuality】.
**Average Outcome:** > The birthday was celebrated, gifts were given and received. The emotional undercurrents remain, but the surface is smooth. > null
**Failed Outcome:** > The awkward moments overshadowed the joy. You feel like a child performing adulthood for your family. You gained 【Yourself: A nagging sense of not measuring up to the “18-year-old” ideal】.