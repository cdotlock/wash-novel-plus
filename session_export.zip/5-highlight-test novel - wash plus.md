# 5-highlight.md
## Node Numbering & Name
Node Number: 5-highlight
Node Name: 喧嚣中的裂痕与禁忌之吻
Preceding Node: 4-normal

## I. Event Positioning
Event Type: Highlight Mainline Event
Dungeon: 卡特莱特宅邸 / 生日派对现场
Main Output: 与Aiden的禁忌关系突破，自我认知混乱，与Jason the Brave关系的潜在裂痕。

## II. Characters Present
**Name:** Super Aves
**Identity/Motivation:** 生日主角 / 试图在家族控制的缝隙中享受自由与恋情，却遭遇意料之外的越界冲击。
**Visual Feature List:**
- **Outfit:**
  - Top: 无袖红色缎面短裙，在旋转灯光下反射暗哑光泽。
  - Bottom: 裙摆至大腿中部。
  - Footwear: 银色细带高跟鞋。
- **Accessories & Equipment:**
  - 左手腕佩戴母亲遗留的镶钻银手镯。
  - 颈间佩戴Aiden赠送的“A”字钻石项链。
  - 耳垂上刚戴好Jason the Brave赠送的镶钻耳钉。

**Name:** Aiden
**Identity/Motivation:** 暴躁的保护者与越界者 / 目睹Super Aves与男友亲热后情绪失控，试图以强硬方式重新宣示“主权”。
**Visual Feature List:**
- **Outfit:**
  - Top: 深灰色修身衬衫，袖口卷至小臂，领口纽扣解开一颗。
  - Bottom: 黑色长裤。
  - Footwear: 黑色皮质休闲鞋。
- **Accessories & Equipment:**
  - 手腕佩戴黑色战术手表。
  - 身上带着淡淡的威士忌酒气。
  - 头发略显凌乱，眼神在昏暗光线下异常锐利。

**Name:** Jason the Brave
**Identity/Motivation:** 醉酒男友 / 沉浸在派对氛围与爱意中，行为逐渐失控。
**Visual Feature List:**
- **Outfit:**
  - Top: 黑色衬衫，因跳舞和拥抱出现褶皱，领口微开。
  - Bottom: 深色牛仔裤。
  - Footwear: 运动鞋。
- **Accessories & Equipment:**
  - 浑身散发明显的酒精与烟草混合气味。
  - 眼神迷离，笑容因醉酒而略显迟钝。

**Name:** Summer
**Identity/Motivation:** 闺蜜与同盟 / 享受派对，敏锐察觉好友的异常。
**Visual Feature List:**
- **Outfit:**
  - Top/Bottom: 银色闪片吊带短裙。
  - Footwear: 黑色厚底靴。
- **Accessories & Equipment:**
  - 妆容精致，但因出汗和热闹略有花掉。
  - 手里握着一个空酒杯。

## III. Key Dialogue
△Aiden: (压低声音，带着怒意) “我不喜欢别人碰你。”
△Super Aves: (反击) “我有男朋友。你又不是我哥哥。你无权管我。”
△Aiden: (在吻她之前，低沉地) “别提Summer。”
△Super Aves: (推开后，内心独白) “What did he just do?”

## IV. Context
这是Super Aves的十八岁生日派对夜晚。此前，她刚通过“审查”晚宴，并收到母亲遗物与Aiden的项链，与家族关系出现微妙缓和。她满心以为这是一个可以暂时抛开控制、享受自由与恋情的夜晚。然而，Aiden的监视与越界行为，将她从喧闹的庆祝中拽入一场情感与伦理的风暴中心。

## V. Event描述
在震耳欲聋的生日派对上，Super Aves与醉酒的男友Jason the Brave在舞池中亲密共舞、亲吻。Jason因醉酒行为逐渐越界。Aiden目睹一切，在Jason的手即将碰到敏感部位时，强行将Super Aves拽离舞池，拖至黑暗无光的二楼走廊。在走廊里，Aiden以保护者姿态质问Super Aves与Jason的关系，承认自己“不喜欢别人碰她”。Super Aves激烈反驳，指出Aiden并无权力干涉。情绪对峙达到顶点时，Aiden突然低头强吻了Super Aves。这个吻粗暴、带着占有意味，让Super Aves瞬间陷入巨大的震惊、羞愧与自我怀疑——她并未立刻拒绝。Aiden在吻后等待她的“判决”，但Super Aves在混乱中推开他。事件以派对结束、Super Aves与Summer回房告终，但那个禁忌的吻已在她心中投下无法抹去的阴影，彻底搅乱了与Aiden、与Jason the Brave，乃至与她自己的关系。

## VI. Core Conflict
在家族名义的“保护”与真实越界的“欲望”之间，Super Aves必须面对Aiden突如其来的侵犯，同时处理自己对这一侵犯的混乱反应（未立即拒绝的羞愧），并重新审视她与男友Jason the Brave的关系。核心在于维护自我边界与应对复杂情感的拉扯。

## VII. Scripted Intro Text
**时间:** 深夜，派对高潮。
**场景:** 卡特莱特宅邸一楼客厅/舞池 → 二楼黑暗走廊。
**人物:** Super Aves, Jason the Brave, Aiden, Summer (背景)。

音乐是实体化的浪潮，轰击着墙壁与耳膜。旋转彩灯将人影切割成闪烁的色块。
**△SFX:** 低音炮持续的嗡鸣，人群的欢笑与尖叫混杂。

镜头穿过攒动的人头，锁定舞池中央。
特写：Super Aves的红色裙摆随着慢歌节奏轻轻摆动。Jason the Brave的手牢牢扣住她的腰，将她拉近，直到毫无缝隙。他的吻落在她的颈侧，带着浓重的酒气。
**△Jason the Brave:** (含糊地) “You look beautiful…”

Super Aves仰头回应他的亲吻，手指陷入他黑色衬衫的布料。灯光滑过她手腕的银镯和颈间的钻石“A”，冰冷与炽热在她身上交汇。

突然，镜头切换至舞池边缘的阴影中。
Aiden靠墙站立，手里的酒杯已空。他的眼睛像两点寒星，穿透闪烁的光线，死死钉在Super Aves与Jason the Brave纠缠的身影上。他的下颌线绷紧，握着空杯的手指关节微微发白。

舞池中，慢歌进入副歌。Jason the Brave的手掌开始下滑，从腰际移向裙摆的边缘——
就在指尖即将触碰到敏感区域的刹那，一只更强硬、更迅捷的手从Super Aves背后伸来，像铁钳般抓住了她的上臂！

**△SFX:** 玻璃杯摔落在地的清脆碎裂声（来自Aiden松手）。

音乐声仿佛瞬间被抽空。Super Aves被一股巨大的力量猛地向后拽去，脱离Jason the Brave的怀抱。她踉跄着回头，只看到Aiden阴沉到极点的脸，在变幻的灯光下宛如修罗。

他甚至没有看Jason the Brave一眼，仿佛对方只是空气。他紧抿着唇，一言不发，转身就拖着挣扎的Super Aves朝楼梯方向走去，粗暴地分开人群。
**△Super Aves:** (惊呼) “Aiden! What are you doing?！”
她的高跟鞋在地板上刮出刺耳的声音，但无法抵抗他的力量。

镜头跟随他们冲上楼梯，将楼下的喧嚣与音乐迅速隔绝。
二楼走廊，一片近乎绝对的黑暗，只有远处某个房间门下透出极微弱的光晕。Aiden将她一路拖到她的房门前才停下，转身，将她重重按在门板上。

**△SFX:** Super Aves后背撞上木门的闷响。

两人的呼吸在寂静的黑暗中异常清晰。Aiden的影子完全笼罩了她。他低下头，呼出的气息灼热，带着威士忌的味道，与方才Jason the Brave的酒气截然不同——更烈，更危险。
**△Aiden:** (声音压得极低，却字字清晰) “我不喜欢别人碰你。”

Super Aves的心脏狂跳，愤怒与莫名的恐慌交织。她试图挣脱他的钳制。
**△Super Aves:** “我有男朋友。你又不是我哥哥。你无权管我。”
她的反驳在黑暗中显得尖锐，却也单薄。

Aiden的眼神更深，更暗。他逼近一步，几乎与她鼻尖相触。
**△Aiden:** “别提Summer。”
这句话像是一个警告，也像是一个开关。

下一秒，没有任何预兆，他猛地低头，吻住了她的唇。

这不是轻柔的试探，而是带着怒意、蛮横与某种绝望的侵占。Super Aves的眼睛在瞬间惊恐地睁大，映着远处那一点微光。她的身体僵硬，大脑一片空白。时间仿佛被拉长——她能感觉到他嘴唇的力度，他气息的入侵，以及自己心脏快要炸开的轰鸣。

然后，在纯粹的震惊中，她的睫毛颤了颤，缓缓闭上了。原本推拒他胸膛的手，无意识地蜷缩起来，指尖擦过他衬衫的布料。

不知过了几秒，或许是更久，理智猛然回笼。她开始用力挣扎，双手抵住他的胸口，拼命扭头摆脱这个吻。

两人分开，在黑暗中急促地喘息。Super Aves的手还抵在Aiden胸前，指尖能感觉到他衬衫下紧绷的肌肉和剧烈的心跳。她抬起头，对上他近在咫尺的眼睛。那双眼睛里翻涌着她看不懂的情绪，像是在等待，又像是在审判。

她的脸颊发烫，嘴唇残留着被碾压过的微痛和陌生的触感。而比这更灼人的，是心底疯狂滋长的、冰冷的羞愧。

**What did he just do?**
更重要的是——**Why didn't I push him away immediately?**

## VIII. Player Choice Moments

**Choice 1 (No Check Required):**
**Situation:** 唇上残留着Aiden粗暴的触感，震惊与羞愧如冰火交织。他就在咫尺之外喘息，等待你的反应。
1.  **Option Description:** 用尽全力扇他一耳光。
**Choice Result:** 清脆的耳光声在寂静走廊炸响。Aiden的脸被你打得偏过去，但他没躲，只是慢慢转回来，左脸颊浮现红痕。他眼中翻涌的激烈情绪瞬间凝滞，转为一种深不见底的晦暗。他没说话，只是深深看了你一眼，转身沉默地走入黑暗走廊深处，留下你独自在房门前剧烈颤抖。
2.  **Option Description:** 颤抖着后退，声音破碎地质问：“你疯了？”
**Choice Result:** 你的声音带着哭腔，在黑暗中显得脆弱不堪。Aiden没有进一步动作，只是胸膛起伏，看着你像受惊的动物般后退。他喉结滚动了一下，最终什么也没说，抬手用力抹了一下自己的嘴唇，转身大步离开，脚步声沉重而决绝。你背靠着冰凉的门板滑坐下去，抱住膝盖。

**Choice 2 (Check Required):**
**Situation:** Aiden并未离开，他站在几步外阴影里，声音沙哑地打破沉默：“说话。Aves。” 他要求一个回应，一个对他越界行为的“判决”。
1.  **Option Description:** 直视他，冷声命令他永远别再碰你。
**[Backend Check Logic]**: Check Attribute: 意志. Difficulty: 困难
**Choice Result (Success):** 你强压下所有混乱情绪，眼神恢复冰冷与决绝。你的话语像刀子，清晰地划清界限。Aiden身体明显僵了一下，随后他扯出一个近乎自嘲的冷笑，点了点头，转身离开。你成功维护了边界，但看到他离去的背影时，心头莫名一刺。**成功维护了表面尊严，但内在的撼动并未消失。**
**Choice Result (Failure):** 你想表现得强硬，但声音出口却带着不自觉的颤抖和一丝连自己都未察觉的动摇。Aiden捕捉到了这丝动摇，他没有被喝退，反而上前一步，阴影再次笼罩你。“你刚才，没有立刻推开。”他低声指出，让你的羞愧无所遁形。你节节败退，最终在他逼视下仓皇逃进房间。
2.  **Option Description:** 避开他的视线，低声说：“我需要……想想。”
**[Backend Check Logic]**: Check Attribute: 魅力. Difficulty: 普通
**Choice Result (Success):** 你示弱般的迷茫回应，意外地让Aiden周身紧绷的攻击性缓和下来。他没有再逼迫，只是深深看了你一眼，声音低沉：“好。” 他给了你这个空间，但这也意味着你们之间这笔糊涂账，远未算清。**暂时避免了冲突升级，但也给了他某种模糊的希望或解读空间。**
**Choice Result (Failure):** 你的犹豫和软弱被他解读为默许或动摇的信号。他眼神一暗，再度上前，手指擦过你发热的脸颊。“不用想。”他低语，语气里带着一种危险的笃定。你感到更大的压迫感袭来，慌忙躲开，这次他放任你逃进房间，但你知道事情变得更糟了。

**Choice 3 (Check Required):**
**Situation:** 回到房间，Summer察觉你的极度异常，逼问到底发生了什么。酒精和混乱让你几乎崩溃。
1.  **Option Description:** 扑进她怀里，哽咽着说出全部经过。
**[Backend Check Logic]**: Check Attribute: 魅力. Difficulty: 普通
**Choice Result (Success):** Summer在震惊过后，紧紧抱住你。她没有评判，只是愤怒于Aiden的越界，并坚定地站在你这边。“这不是你的错，Aves。是那个混蛋疯了。”她的支持让你沉重的负罪感减轻了些许，你们的关系因共享这个秘密而更加紧密。**获得了关键同盟的情感支持，但秘密的重量也加倍了。**
**Choice Result (Failure):** 你情绪崩溃，语无伦次，描述中无法控制地流露出自己的混乱（包括未立刻推开的事实）。Summer听懂了，她的表情从震惊变为复杂的担忧。“Aves…你对他…”她欲言又止。你的坦白反而让最好的朋友看到了你内心不愿承认的部分，增加了隔阂与担忧。
2.  **Option Description:** 强颜欢笑，撒谎说只是和Jason the Brave吵架了。
**[Backend Check Logic]**: Check Attribute: 智力. Difficulty: 困难
**Choice Result (Success):** 你迅速编造了一个关于Jason the Brave醉酒失态的合理故事，细节逼真，情绪到位。Summer相信了，转而和你一起骂Jason the Brave。你成功保住了这个惊天的秘密，但独自背负的压力让你几乎窒息。**秘密得以保存，但孤立了自己，与最亲密的朋友之间也产生了无形的屏障。**
**Choice Result (Failure):** 你的谎言漏洞百出，眼神躲闪。Summer一眼看穿，她没有戳破，只是深深看了你一眼，说：“好吧，你不想说就算了。”但你知道她不再相信。信任出现了裂痕，她在你身边躺下，背对着你，气氛降至冰点。

## IX. Subsequent Influence
**Perfect Outcome:** > 你以清晰的边界和意志力震慑了Aiden，同时获得了Summer无条件的支持。你获得了 【Aiden：他的越界被明确拒绝，但某种执念更深地沉入眼底】与 【Summer：你们的同盟因共享禁忌秘密而更加牢不可破】。
**Average Outcome:** > 事件以模糊的暂停告终。Aiden暂时退却，但问题悬而未决；Summer有所察觉但未深究。你获得了 【Aiden：你们的关系进入一种紧张而微妙的冻结状态】。
**Failed Outcome:** > 你的混乱和软弱助长了Aiden的危险解读，同时与Summer的信任出现裂痕。你获得了 【Aiden：他认为你并非完全抗拒，潜在的危险性增加】与 【Summer：她对你的隐瞒感到失望与担忧，同盟出现信任危机】。